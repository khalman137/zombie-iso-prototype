CHARACTER BASE MALE 01 — TEST PACK

Frame: 256x256 px
Pivot: 128,224
Height: approx. 115 px
Format: PNG RGBA, transparent background

Included:
- South Idle / Walk
- East Idle / Walk
- Head, Torso, ArmLeft, ArmRight, Legs
- Preview sheets
- manifest.json

This is a functional prototype for engine import, layer alignment and animation testing.
