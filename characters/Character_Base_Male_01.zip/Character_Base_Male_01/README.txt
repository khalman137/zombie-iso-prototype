Character_Base_Male_01

CORRECTED HAIR PACKAGE

- 8 Idle directions
- Head
- Hair
- Torso
- ArmLeft
- ArmRight
- Legs
- PNG RGBA
- Frame: 256x256
- Pivot: 128,224
- Hair alpha: only 0 or 255
- No clothing
- No shoes
