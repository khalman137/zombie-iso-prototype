Character_Base_Male_01

REAL ENGINE TEST PACKAGE
Reference: user-approved character image

Included:
- South Idle
- South Walk, 8 frames
- Head
- Torso
- ArmLeft
- ArmRight
- Legs
- Preview files
- manifest.json

Technical:
- PNG RGBA
- frame 256x256
- pivot 128,224
- character height about 115 px
- transparent background
