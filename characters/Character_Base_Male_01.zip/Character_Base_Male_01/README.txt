Character_Base_Male_01

Included:
- 8 directions
- Idle
- Head
- Hair
- Torso
- ArmLeft
- ArmRight
- Legs
- Preview
- manifest.json

Technical:
- PNG RGBA
- Transparent background
- Frame 256x256
- Pivot 128,224
- Hair is separate
- No clothing
- No shoes
