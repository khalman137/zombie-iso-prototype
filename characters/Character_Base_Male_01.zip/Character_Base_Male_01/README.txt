Character_Base_Male_01

TEST PACKAGE FOR ENGINE IMPORT

Included:
- 8 directions
- Head, Torso, ArmLeft, ArmRight, Legs
- Idle: 1 frame
- Walk: 8 frames
- Preview sheets
- manifest.json

Technical:
- PNG RGBA 32-bit
- Transparent background
- Frame size: 256x256 px
- Pivot: 128,224
- Sprite sheet size for Walk: 2048x256 px
- Average male body proportions
- No hair
- No clothing
- No footwear
